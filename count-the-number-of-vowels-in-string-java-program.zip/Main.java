import java.util.*;
public class Main
{
  public static void main (String[]args)
  {
    Scanner num = new Scanner (System.in);
    String a = num.nextLine ();
    int h = 0;
    for (int i = 0; i < a.length (); i++)
      {
	char ch = a.charAt (i);
	if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u'
	    || ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U')
	  {
	    h++;
	  }
      }
    System.out.print (h);
  }
}


